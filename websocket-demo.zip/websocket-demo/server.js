// server.js
const express = require('express');
const http = require('http');
const path = require('path');
const WebSocket = require('ws');

const PORT = process.env.PORT || 3000;
const app = express();

// Serve static files (public/index.html)
app.use(express.static(path.join(__dirname, 'public')));

// Create HTTP server (so we can attach WebSocket to same port)
const server = http.createServer(app);

// Create WebSocket server attached to the HTTP server
const wss = new WebSocket.Server({ server });

// When a client connects
wss.on('connection', (ws, req) => {
  console.log('New client connected:', req.socket.remoteAddress);

  // Mark alive for heartbeat
  ws.isAlive = true;
  ws.on('pong', () => {
    ws.isAlive = true;
  });

  // Send a welcome message
  ws.send(JSON.stringify({ type: 'welcome', message: 'Connected to WebSocket server' }));

  ws.on('message', (raw) => {
    console.log('Received:', raw);

    // Try parse JSON, otherwise treat as plain text
    let data;
    try {
      data = JSON.parse(raw);
    } catch (err) {
      // echo non-JSON back
      ws.send(JSON.stringify({ type: 'error', message: 'Invalid JSON received', raw: String(raw) }));
      return;
    }

    // Example: if client sends {type: 'broadcast', name, text}
    if (data.type === 'broadcast') {
      const outgoing = {
        type: 'message',
        from: data.name || 'Anonymous',
        text: data.text,
        time: Date.now(),
      };
      // Broadcast to all connected clients (including sender)
      wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify(outgoing));
        }
      });
      return;
    }

    // Example: if client sends {type: 'echo', ...}
    if (data.type === 'echo') {
      ws.send(JSON.stringify({ type: 'echo', data }));
      return;
    }

    // Default: acknowledge
    ws.send(JSON.stringify({ type: 'ack', received: data }));
  });

  ws.on('close', () => {
    console.log('Client disconnected');
  });

  ws.on('error', (err) => {
    console.error('WebSocket error:', err);
  });
});

// Heartbeat to terminate dead sockets
const interval = setInterval(() => {
  wss.clients.forEach(ws => {
    if (!ws.isAlive) return ws.terminate();
    ws.isAlive = false;
    ws.ping(); // will trigger 'pong' from client (handled above)
  });
}, 30000); // every 30s

// Start server
server.listen(PORT, () => {
  console.log(`HTTP + WebSocket server listening on http://localhost:${PORT}`);
});

// Graceful shutdown
function shutdown() {
  console.log('Shutting down...');
  clearInterval(interval);
  wss.clients.forEach(ws => ws.terminate());
  server.close(() => process.exit(0));
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

